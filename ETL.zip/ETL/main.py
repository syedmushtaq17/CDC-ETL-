import json
import logging
from sqlalchemy import create_engine, text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.pool import NullPool
from configparser import ConfigParser
import os
from flatten_json import flatten
import pandas as pd
import schedule
import time
from datetime import datetime


config_file='conf/etl_config.ini'

config=ConfigParser()
config.read(config_file)

tod = time.asctime().split(' ')
tod = ' '.join(tod[:3])


logging.basicConfig(level=logging.DEBUG, filename='./logs/ETL_{}.log'.format(tod), format='%(asctime)s %(levelname)s:%(message)s')
#print(config.sections())

logging.debug("this file has %d words", len(config.sections()))

def connection():
    db_type = config['db_credentials']['db_type']
    host = config['db_credentials']['host']
    port = config['db_credentials']['port']
    username = config['db_credentials']['username']
    password = config['db_credentials']['password']
    db = config['db_credentials']['db']

    # print('{}://{}:{}@{}:{}/{}'.format(db_type,username,password,host,port,db))
    engine = create_engine(
        '{}://{}:{}@{}:{}/{}'.format(db_type,username,password,host,port,db),poolclass=NullPool)
    #connection = engine.connect()
    return engine

# test
tables=config.get('tables','table_list')
tables=tables.split(',')
col_path=config.get('support_files','column_path')
json_cols_path=config.get('support_files','json_cols_path')
output_path=config.get('support_files','output_path')
data_interval=config.get('data_retriving_durations','data_interval')
data_time_dur=config.get('data_retriving_durations','data_time_dur')
interval=config.get('scheduling','interval')
time_dur=config.get('scheduling','time_dur')

# print(type(tables))
# print(json_cols_path)

json_files=os.listdir(json_cols_path)

# print(json_files)
# print(type(json_files))
def start():
    for tab in tables:
        with open(col_path+'/'+tab+'.fmt','r') as f:
            actual_cols=f.read()
            cols=actual_cols.split(',')
            print(type(cols))
            if tab+'_json.fmt' in json_files:
                with open(json_cols_path+'/'+tab+'_json.fmt','r') as jf:
                    jf_cols=jf.read()
                    # print(type(jf_cols))
                    # print(jf_cols)
                    res = json.loads(jf_cols)
                    # print(res)
                    flat_json = flatten(res, '.')
                    print(flat_json)
                    json_cols = ','.join(i for i in flat_json)
                    print(json_cols)
                    # print(type(json_cols)) type is string so splitted
                    for col in cols:
                        js_rep=[i for i in json_cols.split(',') if col+'.' in i]
                        # print(js_rep)
                        js_rep_res=[]
                        for js_i in js_rep:
                            # print(type(js_i),js_i)
                            js_rep_res.append(js_i.replace('.','->>"$.',1)+'"')

                        print(js_rep_res)    # js_rep_res.append()
                        if js_rep:
                            actual_cols=actual_cols.replace(col,','.join(js_rep_res))
                        # print(actual_cols)
                    extract(tab,actual_cols)
                # print(actual_cols)

            else :
                extract(tab,actual_cols)

            # print(cols)
# for i,j,k in zip(tables,col_path,json_cols_path):
#     print(i,j,k)


#print(tables)




#end test for fetching files columns



def extract(table,query_column):
    try:
        logging.debug('Connecting to Database ')
        engine=connection()
        con=''
        con=engine.connect()
        logging.debug('Connection successfull ')
        prev_dur=0

        admin_query='''select dur_time from admin_failed_job where table_name='{}' order by arc_date desc limit 1'''.format(table)
        print(admin_query)
        admin_res=con.execute(text(admin_query)).fetchall()
        print(admin_res)
        if admin_res ==None:
            prev_dur=0
        else:
            for admin_row in admin_res:
                prev_dur=int(str(admin_row[0]).split(',')[0])
        query=''
        print(prev_dur)
        if prev_dur != 0:
            tot_data_time_dur = int(data_time_dur) + int(prev_dur)
        else:
            tot_data_time_dur = data_time_dur
        if data_interval == 'hourly':
            query='''select {} from {} where arc_date between date_format(date_sub(now(),interval {} hour),'%Y-%m-%d %H:00:00') and date_format(now(),'%Y-%m-%d %H:00:00');'''.format(query_column,table,tot_data_time_dur)
        elif data_interval=='minutes':
            query = '''select {} from {} where arc_date between date_format(date_sub(now(),interval {} minute),'%Y-%m-%d %H:%i:00') and date_format(now(),'%Y-%m-%d %H:%i:00');'''.format(
                query_column, table, tot_data_time_dur)
        logging.debug('running query {}'.format(query))
        print(query)
        res=con.execute(text(query)).fetchall()
        logging.debug('Fetched Query Result')
        actual_cols = query_column.replace('->>"$.','.')
        # print(res)
        actual_cols=actual_cols.split(',')
        print(actual_cols)
        df=pd.DataFrame(res,columns=actual_cols)
        logging.debug('data frame created ')

        # df=pd.DataFrame(res,columns=columns)
        # print('df is tehre')




        now_time=datetime.now()
        now_parsed=now_time.strftime('%Y%m%d%H%M%S')
        print(output_path + '/{}_{}.csv.gz'.format(table, now_parsed))
        df.to_csv(output_path +'/{}_{}.csv.gz'.format(table, now_parsed), compression='gzip', index=False, date_format='%Y-%m-%d %H:%M:%S')
        # print(df)
        if prev_dur!=0:
            admin_query_del='''delete from admin_failed_job where table_name='{}';'''.format(table)
            con.execute(admin_query_del)


        return res
    except Exception as e:
        admin_insert_query=''
        if con !='':
            if prev_dur==0:
                admin_insert_query='''insert into admin_failed_job (table_name,dur_time) values ('{}','{}')'''.format(table,str(time_dur)+','+str(interval))
            elif prev_dur!=0:
                prev_dur=int(prev_dur)+int(time_dur)
                admin_insert_query='''update admin_failed_job set dur_time='{}' where table_name = '{}' '''.format(str(prev_dur)+','+str(interval),table)

        if admin_insert_query!='':
            con.execute(admin_insert_query)

        logging.debug('query failed')


        logging.exception(e)
    finally:
        logging.debug('Closing connections for the process')
        if con!= '':
            con.close()






# for hourly time is not required
if interval == 'hourly':
        schedule.every().hour.do(start)
        print('started')
        logging.debug('Started Hourly Scheduling at')

elif interval == 'minutes':
    if time_dur:
        schedule.every(int(time_dur)).minutes.do(start)
        logging.debug('Started minutes Scheduling at {}'.format(time_dur))
    else:
        schedule.every(10).minutes.do(start)
        logging.debug('Started Hourly Scheduling at 10 mins')
elif interval =='day':
    if time_dur:
        schedule.every().day.at(time_dur).do(start)
        logging.debug('Started minutes Scheduling at {}'.format(time_dur))
    else:
        schedule.every().day.at("00:00").do(start)
else:
    pass


def main_task():
    while True:
        # Checks whether a scheduled task
        # is pending to run or not
        schedule.run_pending()
        time.sleep(1)
#extract()
#connection()

